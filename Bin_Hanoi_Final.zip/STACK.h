#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

struct Node {
    float data;
    Node*next;
};


struct Disks {
    float x;
    float y;
    bool live;
    ALLEGRO_BITMAP *image;
};


class STACK {
  public:
    ///CONSTRUCTORS
    STACK();


    ///DESTRUCTOR
    ~STACK();

    void setTop(int t) {
        top = t;
    };
    int getTop() const {
        return top;
    };

    bool isEmptyNode();

    int popNode();
    void pushNode(int n);

    void displayNode();
    void deleteNode();

    void displayInConsole(STACK &S, STACK &D, STACK &I);
    int getCounter();
    Node *head, *tail, *temp, *newnode;


  private:
    int top;

};
#endif // STACK_H_INCLUDED
