/****************************************************************************

Bin (Quoc Dat Phung)
Mrs. Lindsay Cullum
April 30, 2019

Tower of Hanoi Game with Recursive Function
(Goal>3: Animation on Console/ Allegro Display without Hard Code

Problems:
Display function on allegro that prints out the stacks from the linked
list but when put into the recursive function, it does not work. The stacks are
displayed AFTER calling the recursive function, so it proves that the function works.
 Other than that, everything else works fine. I reused the stack header class from the old assignment.
 The recursive function performs accurately with the correct number of steps
(checked with MathIsFun.com). I did not hard code so you can select the number
 of disks however you want.

*****************************************************************************/
#include <iostream>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include "object.h"
#include "functions.h"

int main(int argc, char **argv) /// =========================================
{
    getUserInputInConsole();

    InitAllegroToH();

    return 0;
}











