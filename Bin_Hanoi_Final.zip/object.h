#ifndef OBJECT_H_INCLUDED
#define OBJECT_H_INCLUDED


#define CYAN     al_map_rgb(0,255,255)
#define GREEN    al_map_rgb(0,128,0)
#define WHITE    al_map_rgb(255, 255, 255)
#define YELLOW	 al_map_rgb(255, 225, 25)
#define ORANGE   al_map_rgb(255,127,80)
#define RED      al_map_rgb(176,12,12)
#define BLACK    al_map_rgb(0,0,0)
#include "STACK.h"


/// Constant & Global variables used in main and functions  =====================
/*NUM_D is the size of an array for the number of disks, which explains why I use D[NUM_D].
NUM_D = 7 means that there are 7 disk waiting to be drawn out on the screen.*/

const float FPS = 40;
const int SCREEN_W = 1280;
const int SCREEN_H = 720;
int nDisks = 0;
int moveCounter = 0;



/// Function prototype: ===========================================================
int InitAllegroToH();
void getUserInputInConsole();

void InitConsoleAnimation(int &nDisks, int &moveCounter, STACK &Source, STACK &Inter, STACK &Destin);
void displayInConsole(STACK Source, STACK Inter, STACK Destin);

void DrawDiskInGraphic(STACK P, string name, int nDisks, ALLEGRO_BITMAP *D1, ALLEGRO_BITMAP *D2,
                     ALLEGRO_BITMAP *D3, ALLEGRO_BITMAP *D4, ALLEGRO_BITMAP *D5,
                     ALLEGRO_BITMAP *D6, ALLEGRO_BITMAP *D7);
void moveDisks(int n, int &moveCounter, STACK &S, STACK &D, STACK &I);



#endif // object_H_INCLUDED
