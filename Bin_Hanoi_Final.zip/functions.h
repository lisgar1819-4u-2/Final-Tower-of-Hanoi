#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED


#include <iostream>
using namespace std;

#include "STACK.h"

#include "object.h"


#include <time.h>
#include <time.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>




int InitAllegroToH() {

    float mouse_x = 0;
    float mouse_y = 0;
    bool redraw = true;
    bool doexit = false;
    srand(time(NULL));

    ///STACK DECLARATION HERE;
    STACK Source;
    STACK Inter;
    STACK Destin;

    /// INITIALIZATION of Allegro ======================================
    InitConsoleAnimation(nDisks, moveCounter, Source, Inter, Destin);
    cout << "\nNumber of disks is: " << nDisks << "\nMinimum Moves: " << moveCounter << endl << endl;


    ALLEGRO_DISPLAY *display = NULL;
    ALLEGRO_EVENT_QUEUE *event_queue = NULL;
    ALLEGRO_TIMER *timer = NULL;
    ALLEGRO_BITMAP *mouse_icon_2 = NULL;
    ALLEGRO_BITMAP *B1= NULL; //background 1
    ALLEGRO_BITMAP *D1= NULL;
    ALLEGRO_BITMAP *D2= NULL;
    ALLEGRO_BITMAP *D3= NULL;
    ALLEGRO_BITMAP *D4= NULL;
    ALLEGRO_BITMAP *D5= NULL;
    ALLEGRO_BITMAP *D6= NULL;
    ALLEGRO_BITMAP *D7= NULL;
    ALLEGRO_FONT *font60 = NULL;
    ALLEGRO_FONT *font50 = NULL;
    ALLEGRO_FONT *font75 = NULL;
    ALLEGRO_FONT *font30 = NULL;
    ALLEGRO_FONT *font80 = NULL;
    ALLEGRO_FONT *font40 = NULL;


    if(!al_init()) {
        fprintf(stderr, "failed to initialize allegro!\n");
        return -1;
    }

    display = al_create_display(SCREEN_W, SCREEN_H);
    if(!display) {
        fprintf(stderr, "failed to create display!\n");
        return -1;
    }
    if(!al_install_keyboard()) {
        fprintf(stderr, "failed to initialize the keyboard!\n");
        return -1;
    }
    if(!al_install_mouse()) {
        fprintf(stderr, "failed to initialize the mouse!\n");
        return -1;
    }
    al_hide_mouse_cursor(display); // hide mouse cursor on display. Later we use different mouse icon loaded from bitmap file.

    if(!al_init_primitives_addon()) {
        fprintf(stderr, "failed to initialize primitive addon!\n");
        return -1;
    }

    if(!al_init_image_addon()) {
        fprintf(stderr, "failed to initialize image addon!\n");
        return -1;
    }
    if(!al_init_font_addon()) {
        fprintf(stderr, "failed to initialize font addon!\n");
        return -1;
    }

    if(!al_init_ttf_addon()) {
        fprintf(stderr, "failed to initialize ttf addon!\n");
        return -1;
    }

    mouse_icon_2 = al_load_bitmap("aim-2.png");  // This is new mouse icon on display
    if(!mouse_icon_2) {
        fprintf(stderr, "failed to load bitmap mouse_icon_2.png!\n");
        return -1;
    }

    B1 = al_load_bitmap("background-3.png");
    if(!B1) {
        fprintf(stderr, "failed to load bitmap B1!\n");
        return -1;
    }

    D1 = al_load_bitmap("1.png");
    if(!D1) {
        fprintf(stderr, "failed to load bitmap D1!\n");
        return -1;
    }

    D2 = al_load_bitmap("2.png");
    if(!D2) {
        fprintf(stderr, "failed to load bitmap D2!\n");
        return -1;
    }
    D3 = al_load_bitmap("3.png");
    if(!D3) {
        fprintf(stderr, "failed to load bitmap D3!\n");
        return -1;
    }
    D4 = al_load_bitmap("4.png");
    if(!D3) {
        fprintf(stderr, "failed to load bitmap D4!\n");
        return -1;
    }
    D5 = al_load_bitmap("5.png");
    if(!D3) {
        fprintf(stderr, "failed to load bitmap D5!\n");
        return -1;
    }
    D6 = al_load_bitmap("6.png");
    if(!D3) {
        fprintf(stderr, "failed to load bitmap D6!\n");
        return -1;
    }
    D7 = al_load_bitmap("7.png");
    if(!D3) {
        fprintf(stderr, "failed to load bitmap D7!\n");
        return -1;
    }


    font75 = al_load_ttf_font("comic.ttf", 75, 0);
    font60 = al_load_ttf_font("comic.ttf", 60, 0);
    font50 = al_load_ttf_font("comic.ttf", 50, 0);
    font30 = al_load_ttf_font("courbd.ttf", 28, 0);
    font80 = al_load_ttf_font("courbd.ttf", 75, 0);
    font40 = al_load_ttf_font("courbd.ttf", 33, 0);

    if(!font60) {
        fprintf(stderr, "failed to load font 60!\n");
        return -1;
    }

    if(!font50) {
        fprintf(stderr, "failed to load font 50!\n");
        return -1;
    }

    if(!font75) {
        fprintf(stderr, "failed to load font 75!\n");
        return -1;
    }

    if(!font30) {
        fprintf(stderr, "failed to load font 30!\n");
        return -1;
    }

    if(!font80) {
        fprintf(stderr, "failed to load font 80!\n");
        return -1;
    }

    if(!font40) {
        fprintf(stderr, "failed to load font 40!\n");
        return -1;
    }

    timer = al_create_timer(1.0 / FPS);
    if(!timer) {
        fprintf(stderr, "failed to create timer!\n");
        return -1;
    }

    event_queue = al_create_event_queue();
    if(!event_queue) {
        fprintf(stderr, "failed to create event_queue!\n");
        return -1;
    }


    al_register_event_source(event_queue, al_get_display_event_source(display));
    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_register_event_source(event_queue, al_get_mouse_event_source());
    al_register_event_source(event_queue, al_get_keyboard_event_source());


    al_start_timer(timer);

    while(!doexit) {


        ALLEGRO_EVENT ev;
        al_wait_for_event(event_queue, &ev);



        ///
        /***********************************************************************************************************
        1. UPDATES SECTION: This is where we update the game state, coordinates of moving objects, user's input.
        We use this section to detect user inputs, and response to their requests by running Update(..) programs.
        We can also run other processes to detect other events (such as collision,...)

        ************************************************************************************************************/

        if(ev.type == ALLEGRO_EVENT_TIMER) {  /// 1.1 Change of game state  ====
            redraw = true;
        }
        //else;

        if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { /// 1.2 Change of DISPLAY: closing display  =====
            doexit = true;
        }

        else if(ev.type == ALLEGRO_EVENT_KEY_DOWN) {     /// 1.3 Change of keyboard pressing:

            switch(ev.keyboard.keycode) {
            case ALLEGRO_KEY_ESCAPE:
                doexit = true;
                break;
            }
        }

        else if(ev.type == ALLEGRO_EVENT_KEY_UP) { /// 1.4 Detection of keyboard releasing events starts here: (releasing key means not moving)
            switch(ev.keyboard.keycode) {
            case ALLEGRO_KEY_ESCAPE:
                doexit = false;
                break;
            }
        }

        /// 1.5 Detection of MOUSE events   =============================================

        else if(ev.type == ALLEGRO_EVENT_MOUSE_AXES || ev.type == ALLEGRO_EVENT_MOUSE_ENTER_DISPLAY) {
            mouse_x = ev.mouse.x;
            mouse_y = ev.mouse.y;
        }

        else if(ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) { //if(ev.mouse.button & 1)

        }

        else if (ev.mouse.button & 2) {
            doexit = false;
        }


        /***********************************************************************************************************
        2. DISPLAY SECTION : this section displays moving objects 60 times per second. We use this section to also Initialize
        processes (ex. Draw(..), play(..), print(..),...).

        ************************************************************************************************************/

        if(redraw && al_is_event_queue_empty(event_queue)) {

            redraw = false;

            al_draw_bitmap(B1,0, 0, 0);
            ///receiving number of nodes to draw
            int k = Source.getCounter();
            int m = Inter.getCounter();
            int l = Destin.getCounter();

            ///drawing stacks with nodes
            DrawDiskInGraphic(Source, "S",k, D1, D2, D3, D4, D5, D6, D7);
            DrawDiskInGraphic(Inter, "I",m, D1, D2, D3, D4, D5, D6, D7);
            DrawDiskInGraphic(Destin, "D",l, D1, D2, D3, D4, D5, D6, D7);

            //mouse
            al_draw_bitmap(mouse_icon_2, mouse_x, mouse_y, 0);
            al_flip_display();

        }
    }
    al_destroy_bitmap(B1);
    al_destroy_bitmap(D1);
    al_destroy_bitmap(D2);
    al_destroy_bitmap(D3);
    al_destroy_bitmap(D4);
    al_destroy_bitmap(D5);
    al_destroy_bitmap(D6);
    al_destroy_bitmap(D7);


    al_destroy_font(font50);
    al_destroy_font(font60);
    al_destroy_font(font75);
    al_destroy_font(font30);
    al_destroy_font(font80);
    al_destroy_font(font40);
    al_destroy_bitmap(mouse_icon_2);
    al_destroy_event_queue(event_queue);
    al_destroy_timer(timer);
    al_destroy_display(display);


    Source.deleteNode();
    Inter.deleteNode();
    Destin.deleteNode();
    return 0;

}

void getUserInputInConsole() {
    while ( !(nDisks>=1 && nDisks<=7)) {
        cout << "Enter a number of Disks to be mounted on Source, between 1-7: ";
        cin >> nDisks;
        if (nDisks>=1 && nDisks<=7) {
            break;
        }
    }
}




void InitConsoleAnimation(int &nDisks, int &moveCounter, STACK &Source, STACK &Inter, STACK &Destin) {

    for (int i = nDisks; i >= 1; i--) {
        Source.pushNode(i);
    }

    cout << endl << endl << "Observe all disks were moved from Source to Destination:\n";
    displayInConsole(Source,Inter,Destin);
    moveDisks(nDisks, moveCounter, Source, Destin, Inter);

}


int STACK::getCounter() {
    ///see how many nodes are there in the stack.
    int counter = 0;
    temp = head;

    while (temp != NULL) {
        temp = temp->next;
        counter++;
    }
    ///return number of nodes
    return counter;
}

void DrawDiskInGraphic(STACK P, string name, int nDisks, ALLEGRO_BITMAP *D1, ALLEGRO_BITMAP *D2,
                       ALLEGRO_BITMAP *D3, ALLEGRO_BITMAP *D4, ALLEGRO_BITMAP *D5,
                       ALLEGRO_BITMAP *D6, ALLEGRO_BITMAP *D7) {
/// Function to load all the initial disks to the peg Source, to assign its coordinates and image

    int dataNum = 0;
    int x, y;

    P.temp = P.head;


    while (P.temp!=NULL) {
        dataNum = P.temp->data;

        if (name == "S") {
            x = 220 - 175;
        } else if (name == "I") {
            x = 634 - 175;
        } else if (name == "D") {
            x = 1050 - 175;
        } else {
            cout << "\nUnknown Name Type Node\n" << endl;
        }
        ///the y value should be the same for all stacks.
        ///Only the x value changes.
        y = 560 - 30*nDisks;
        nDisks--;


        switch(dataNum) {
        case 1 :
            al_draw_bitmap(D1,x, y, 0);
            break;
        case 2:
            al_draw_bitmap(D2,x, y, 0);
            break;
        case 3:
            al_draw_bitmap(D3,x, y, 0);
            break;
        case 4:
            al_draw_bitmap(D4,x, y, 0);
            break;
        case 5:
            al_draw_bitmap(D5,x, y, 0);
            break;
        case 6:
            al_draw_bitmap(D6,x, y, 0);
            break;
        case 7:
            al_draw_bitmap(D7,x, y, 0);
            break;
        default:
            cout << "Unknown image" << endl;
        }
        //move to the next node
        P.temp = P.temp->next;

    }

}


void displayInConsole(STACK Source, STACK Inter, STACK Destin) {
    ///Display stacks on the console
    cout<< "\nSource: \n";
    Source.displayNode();

    cout<< "\nIntermediate: \n";
    Inter.displayNode();

    cout<< "\nDestination: \n";
    Destin.displayNode();

    cout << "\n________________________\n" << endl;
}


void moveDisks(int n, int &moveCounter, STACK &S, STACK &D, STACK &I) {

    if (n==1) {
        D.pushNode(S.popNode());
        //system("pause");
        displayInConsole(S,I,D);
        moveCounter++;

        return;
    }
    moveDisks(n-1, moveCounter, S, I, D);


    D.pushNode(S.popNode());
    displayInConsole(S,I,D);


    moveCounter++;
    moveDisks(n-1, moveCounter, I,D, S);

}


#endif // FUNCTIONS_H_INCLUDED
