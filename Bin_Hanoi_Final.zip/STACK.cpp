
#include <iostream>
using namespace std;

#include "STACK.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>



///DEFINITIONS OF CONSTRUCTORS
STACK::STACK() {
    setTop(-1);

    head = NULL;
    tail = NULL;
}

STACK::~STACK() {

}

bool STACK::isEmptyNode() {
    if (getTop() == -1) {
        return true;  //stack has no nodes
    } else {
        return false; //stack has nodes
    }
}


int STACK::popNode() {
    int n;
    if (!isEmptyNode() && head != NULL) {

        temp = head;
        n = temp->data;
        //move head to next element
        //to exclude the top element

        head = head->next;
        //delete top element
        delete temp;
        //top decrements
        setTop(getTop()-1);
        return n;
    } else {
        cout << "\nLinked List's Empty.\n";
        return 404;
    }
}

void STACK::pushNode(int n) {
    //push a new node
    newnode = new Node;
    //user pushes number
    //so number is put into
    //new node's data
    newnode->data = n;
    //insert node at the BEGINNING
    //that's where the top of the
    //linked list is.
    newnode->next = head;
    //make newnode the head.
    head = newnode;
    //increment top
    setTop(getTop()+1);
}


void STACK::displayNode() {
//display starting at variable "top"
//print until top is 0;
    // temp = new Node;
    int diskCounter = 0;

    temp = head;

    while (temp!=NULL) {
        diskCounter++;
        cout << temp->data << endl;
        ///diskData = temp->data;
        temp = temp->next;
    }
    diskCounter = 0;
}

void STACK::deleteNode() {

    for (int i = 0; i<getTop(); i++) {
        popNode();

        if (head == NULL) {
            break;
        }
    }

    cout << "Delete Successfully" << endl;

}
